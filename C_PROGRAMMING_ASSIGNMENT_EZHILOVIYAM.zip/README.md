# C Programming Assignment - 1

**Name:** Ezhiloviyam. S  
**Registration Number:** 1912260591

All 10 programs are combined in `all_programs.c`.

## Run
Compile using GCC:
```bash
gcc all_programs.c -o all_programs
./all_programs
```
Then select a question number from 1 to 10 and enter that question's input.

**Note:** The assignment does not fully specify the road-selection rule in Question 6; the code uses car number modulo 3 as an assumption matching the sample.
